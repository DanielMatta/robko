<?php
namespace App\Http\Actions;
// use Illuminate\Http\Request;
// use App\Models\Post;
use Illuminate\Support\Facades\Http;
use Http\Controllers\ClassroomController;

class AddFloorToClassroom{
    public function handle(){
        //zrobit to cez match(true) a cez idcko lebo idu zaradom poschodia
    }
}
