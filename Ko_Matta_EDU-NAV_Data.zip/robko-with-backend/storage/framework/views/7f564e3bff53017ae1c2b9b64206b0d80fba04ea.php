<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ropko</title>
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css"
     integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI="
     crossorigin=""/>
     
     
</head>
<body>
    <div id="test" data-shortnames= <?php echo e($shortnames); ?> data-classnames = <?php echo e($schoolclassnames); ?>></div>
    <div id="app"> </div>

	<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

</body>
</html>
<?php /**PATH /Users/dano/Documents/robko/robko-with-backend/resources/views/app.blade.php ENDPATH**/ ?>