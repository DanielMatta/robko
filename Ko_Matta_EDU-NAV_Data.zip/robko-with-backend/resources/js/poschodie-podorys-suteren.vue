<template>
<svg id="suteren" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="6528" height="4896" viewBox="0 0 6528 4896">
  <defs>
    <linearGradient id="linear-gradient" x1="4522" y1="3767" x2="4522" y2="334" gradientUnits="userSpaceOnUse">
      <stop offset="-4.5"/>
      <stop offset="5.5" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="linear-gradient-2" x1="3438" y1="3758" x2="3438" y2="2967" xlink:href="#linear-gradient"/>
    <linearGradient id="linear-gradient-3" x1="2602" y1="3768" x2="2602" y2="438" xlink:href="#linear-gradient"/>
  </defs>
  <path id="chodba_vpravo" class="cls-1" d="M3677,449H4723V334h153V473h491V676H4862v867h146v955H4855V2396H4750l1,206h114v201H4676v819h338v145H4517V2586h125V1543h64V673H3680Z"/>
  <path id="chodba_main" class="cls-2" d="M2411,3758V3323h175v341h678V3321h415v339h838V2967H2359v791h52Z"/>
  <path id="chodba_vlavo" class="cls-3" d="M3298,439V666H2225v874h125V3768H1906V3410h285V2587H1923V1537h122V664h-54V438Z"/>
  <path id="schody_right" class="cls-4" d="M3737,3323h716v301H3732Z"/>
  <path id="schody_left" class="cls-4" d="M2624.32,3323.5H3202.9v301H2620.28Z"/>
  <path id="Vytah" class="cls-4" d="M2414,3330h174v351H2407Z"/>
  <path id="vchod" class="cls-4" d="M3266,3323h418v346H3264Z"/>
  <path id="ucebna_115" class="cls-4" d="M1217,443v575h475V675h308l-2-236Z"/>
  <path id="obrys" class="cls-5" d="M1219,100H5670l3,924-822-2v522l474,2V2608H5006V3775h381V4867H4711V3769H4514v-94H2412v94H2256V4859H1527V3769h377V2589H1523V1532h213V1024H1199Z"/>
  <path id="telocvicna" class="cls-4" d="M4712,3771h678V4866H4707Z"/>
  <path id="jedalen" class="cls-4" d="M1527.07,3771.5h736.35v1095H1521.64Z"/>
  <path id="ucebna_112" class="cls-4" d="M2069.18,99.694h817.74V423.306H2063.15Z"/>
  <path id="ucebna_124" class="cls-4" d="M1694.25,669.95H2053.5v335.1H1691.6Z"/>
  <path id="ucebna_132" class="cls-4" d="M1732.4,1027.8h315.62v503.4H1730.07Z"/>
  <path id="miestnosti4" class="cls-4" d="M1905.16,2586.92h278.79v682.16H1903.1Z"/>
  <path id="pani_obedarka" class="cls-4" d="M1905.6,3271.21h278.91v120.58H1903.54Z"/>
  <path id="wc_ziaci" class="cls-4" d="M1539.24,1523.66h386.44v147.68H1536.39Z"/>
  <path id="idk2" class="cls-4" d="M1539.6,1688.02h386.88v200.96H1536.75Z"/>
  <path id="ucebna_138" class="cls-4" d="M1539.6,1893.05h386.88v354.89H1536.75Z"/>
  <path id="upratovacky" class="cls-4" d="M1539.45,2453.2h387.06v147.6H1536.6Z"/>
  <path id="bufet" class="cls-4" d="M1539.6,2251.8h386.91v186.4H1536.75Z"/>
  <path id="kabinet_telesna" class="cls-4" d="M4865.66,2618.71l144.71-.25,0.31,180.83-148.71.25Z"/>
  <path id="schody_triedna" class="cls-4" d="M4755,2404h102v100h149v99H4758Z"/>
  <path id="miestnosti2" class="cls-4" d="M2224.81,657.453H3348.8v348.1H2216.52Z"/>
  <path id="ucebna_87" class="cls-4" d="M3610.71,657.511h570.93V1005.49H3606.5Z"/>
  <path id="miestnosti3" class="cls-4" d="M4187.03,657.511h508.82V1005.49H4183.28Z"/>
  <path id="ucebna_120" class="cls-4" d="M1584.18,99.52h356.37V423.48h-359Z"/>
  <path id="idk" class="cls-4" d="M1933.36,99.491h125.25V423.509H1932.43Z"/>
  <path id="ucebna_121" class="cls-4" d="M1213.73,99.491h344.21V423.509H1211.19Z"/>
  <path id="satna_1" class="cls-4" d="M4679.03,3228.94h324.49v378.12H4676.63Z"/>
  <path id="satna_1_copy" data-name="satna_1 copy" class="cls-4" d="M4678.97,2805.99h324.52v423.02H4676.57Z"/>
  <path id="wc_ucitelia" class="cls-4" d="M5005.97,2487.99h324.52v135.02H5003.57Z"/>
  <path id="wc_ziaci-2" data-name="wc_ziaci" class="cls-4" d="M5005.97,2348.99h324.52v135.02H5003.57Z"/>
  <path id="ucebna_74A" class="cls-4" d="M5006,2036.41h324.49v309.18H5003.6Z"/>
  <path id="ucebna_74B" class="cls-4" d="M5006,1708.41h324.49v309.18H5003.6Z"/>
  <path id="registratura" class="cls-4" d="M5006,1550.18h324.49v152.64H5003.6Z"/>
  <path id="ucebna_95A" class="cls-4" d="M4863.61,679.49h513.71v327.02h-517.5Z"/>
  <path id="ucebna_95B" class="cls-4" d="M5374.34,482.729h291.57V999.271H5372.19Z"/>
  <path id="ucebna_96" class="cls-4" d="M5284.06,96.148h377.75v377.7H5281.27Z"/>
  <path id="ucebna_100" class="cls-4" d="M4882.06,96.148h377.75v377.7H4879.27Z"/>
  <path id="ucebna_90" class="cls-4" d="M4282,95.508h442.36V443.491H4278.74Z"/>
  <path id="ucebna_106" class="cls-4" d="M3616,95.508h442.36V443.491H3612.74Z"/>
  <path id="spojka106_90" class="cls-4" d="M4050.96,95.508h221.78V443.491H4049.32Z"/>
  <path id="spojka90_100" class="cls-4" d="M4721.61,91.317h149.93V322.683H4720.5Z"/>
  <path id="ucebna_110" class="cls-4" d="M3191.83,108.217h173.7V426.783H3190.55Z"/>
  <path id="ucebna_111" class="cls-4" d="M3003.84,108.217h173.69V426.783H3002.55Z"/>
  <path id="spojka112_111" class="cls-4" d="M2882.92,108.514h112.02V427.486H2882.1Z"/>
</svg>

</template>

<script>
  export default {
    name: 'poschodiePodorys1',

    props: {
      width: {
        type: String,
        required: false
      },

      height: {
        type: String,
        required: false
      },

      size: {
        type: String,
        required: false
      }
    },

    computed: {
      widthAttr() {
        if (this.height) return undefined;
        if (this.size) return this.size;
        return this.width || "4645px";
      },

      heightAttr() {
        if (this.width) return undefined;
        if (this.size) return this.size;
        return this.height || "2145px";
      }
    }
  }
</script>

<style lang="scss">
           .cls-1, .cls-2, .cls-3, .cls-4, .cls-5 {
        stroke: #000;
        stroke-width: 25px;
        fill-rule: evenodd;
      }

    //   .cls-1 {
    //     fill: url(#linear-gradient);
    //   }

    //   .cls-2 {
    //     fill: url(#linear-gradient-2);
    //   }

    //   .cls-3 {
    //     fill: url(#linear-gradient-3);
    //   }

      .cls-4 {
        fill: #f27405;
      }

      .cls-5 {
        fill: none;
      }
      @keyframes blink1-anim {
  0% { fill: #800; }
  33% { fill: #f00; }
  66% { fill: #800; }
  100% { fill: #800; }
}
@keyframes blink2-anim {
  0% { fill: rgb(16, 136, 0); }
  33% { fill: rgb(47, 255, 0); }
  66% { fill: rgb(0, 136, 2); }
  100% { fill: rgb(0, 136, 48); }
}
.blink1 {
  animation: blink1-anim 1.5s infinite;
}
.blink2 {
  animation: blink2-anim 1.5s infinite;
}

    </style>
