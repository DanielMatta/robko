<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>How To Install Vue 3 in Laravel 9 with Vite</title>
</head>
<body>
	<div id="app"></div>

	<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>
</html><?php /**PATH /Users/dano/Documents/robko/laravel9-vue3-vite/resources/views/app.blade.php ENDPATH**/ ?>