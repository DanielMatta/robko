<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Laravel</title>
</head>
<body>

<h3><?php echo e($shortname); ?></h3>

</body>
</html>
<?php /**PATH /Users/dano/Documents/robko/robko-with-backend/resources/views/demo/index.blade.php ENDPATH**/ ?>