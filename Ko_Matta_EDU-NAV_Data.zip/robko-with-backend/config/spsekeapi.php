<?php

return [
    'api_key' => env('API_KEY_EDUPAGE'),
    'base_url_api' => env('SPSEKE_API_BASE_URL')

];
